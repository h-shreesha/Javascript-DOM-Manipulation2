const container;
const error;

function getAge(){
    
    
}

function calcAge(){ 
    
}

function displayAge(){
    
    
}

